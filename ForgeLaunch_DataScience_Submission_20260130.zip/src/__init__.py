"""
Forge Launch Data Science - Source Package

Root package for all data science implementations.
"""

__version__ = "0.1.0"
__author__ = "Your Name"
